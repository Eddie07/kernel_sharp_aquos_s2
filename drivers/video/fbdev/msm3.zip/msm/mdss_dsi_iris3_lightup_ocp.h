#ifndef MDSS_DSI_IRIS3_LIGHTUP_OCP
#define MDSS_DSI_IRIS3_LIGHTUP_OCP

#include "mdss_dsi.h"

/* TODOS */
#define IRIS_MIPI_TX_HEADER_ADDR  0xF0C1C010
#define IRIS_MIPI_TX_PAYLOAD_ADDR  0xF0C1C014

#define OCP_BURST_WRITE 0x0
#define OCP_SINGLE_WRITE_BYTEMASK 0x4
#define OCP_SINGLE_WRITE_BITMASK 0x5
#define PXLW_DIRECTBUS_WRITE 0xC
#define OCP_SINGLE_READ 0x8

#define DMA_TPG_FIFO_LEN 64

#define CMD_PKT_SIZE 512

#define TEST_ADDR 0xF1240114

#define OCP_HEADER 4  /*4bytes */
#define OCP_MIN_LEN 12  /* 12bytes */

#define DSI_CMD_CNT 20

struct iris_ocp_burst_header {
	u32 ocp_type:4;
	u32 reserved:28;
};

struct iris_ocp_read_header {
	u32 ocp_type:4;
	u32 reserved:28;
};

struct iris_ocp_single_bytemask_header {
	u32 ocp_type:4;
	u32 bytemask1:4;
	u32 bytemask2:4;
	u32 bytemask3:4;
	u32 bytemask4:4;
	u32 bytemask5:4;
	u32 bytemask6:4;
	u32 bytemask7:4;
};

struct iris_ocp_single_bitmask_header {
	u32 ocp_type:4;
	u32 reserved:28;
};

struct iris_ocp_direct_bus_header {
	u16 ocp_type:4;
	u16 reserved:12;
	u16 slot_select;
};

union iris_ocp_cmd_header {
	struct iris_ocp_burst_header st_ocp_burst;
	struct iris_ocp_read_header st_ocp_rd;
	struct iris_ocp_single_bytemask_header st_ocp_bytemask;
	struct iris_ocp_single_bitmask_header st_ocp_bitmask;
	struct iris_ocp_direct_bus_header st_ocp_directbus;
	u32 header32;
};


struct iris_mipi_tx_cmd_hdr {
	u8 dtype;
	/* for short command, means parameter1 and parameter2.
	for long command, means command length*/
	u8 len[2];
	u8 writeFlag:1; /*Read = 0, Write =1*/
	u8 linkState:1; /* HS=0, LP =1 */
	u8 longCmdFlag:1; /* short = 0, long =1*/
	u8 reserved:5; /* =0 */
};

union iris_mipi_tx_cmd_header {
	struct iris_mipi_tx_cmd_hdr stHdr;
	u32 hdr32;
};

union iris_mipi_tx_cmd_payload {
	u8 p[4];
	u32 pld32;
};

struct iris_ocp_cmd {
	char cmd[CMD_PKT_SIZE];
	int cmd_len;
};

struct iris_ocp_dsi_tool_input {
	__u16 iris_ocp_type;
	__u16 iris_ocp_cnt;
	__u32 iris_ocp_addr;
	__u32 iris_ocp_value;
	__u32 iris_ocp_size;
};


void iris_ocp_write(u32 address, u32 value);
void iris_ocp_write2(u32 header, u32 address, u32 size, u32 *pvalues);
u32 iris_ocp_read(u32 address, u32 type);

void iris_write_test(
		struct mdss_dsi_ctrl_pdata *ctrl,
		u32 iris_addr, int ocp_type, u32 pkt_size);
void iris_write_test_muti_pkt(
		struct mdss_dsi_ctrl_pdata *ctrl,
		struct iris_ocp_dsi_tool_input *ocp_input);

int  iris_dsi_cmds_send(
		struct mdss_dsi_ctrl_pdata *ctrl, struct dsi_panel_cmds *pcmds);
u32  iris_dsi_cmds_read_send(
		struct mdss_dsi_ctrl_pdata *ctrl, struct dsi_panel_cmds *pcmds);
void iris_panel_cmd_passthrough(
		struct mdss_dsi_ctrl_pdata *ctrl, struct dcs_cmd_req *cmdreq);

#endif
